from .dummy_solver import DummySolver

__all__ = [
    'DummySolver'
]