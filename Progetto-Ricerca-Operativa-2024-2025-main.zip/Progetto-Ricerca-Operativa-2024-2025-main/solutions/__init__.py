from .solution import Solution

__all__ = [
    'Solution'
]