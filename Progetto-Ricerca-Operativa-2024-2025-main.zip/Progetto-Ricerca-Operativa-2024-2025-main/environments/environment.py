class Environment():
    def __init__(self, inst):
        self.inst = inst